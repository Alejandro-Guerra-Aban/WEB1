
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
/**
 *
 * @author WEB1-09
 */
public class ejercicios_arrays {

    public static void main(String[] args) {
        System.out.println("Empezamos");
        Scanner sc = new Scanner(System.in);
        System.out.println(" - MENU -");
        System.out.println("1. Ejercicio 1");
        System.out.println("2. Ejercicio 2");
        System.out.println("3. Ejercicio 3");
        System.out.println("4. Ejercicio 4");
        System.out.println("5. Ejercicio 5");
        System.out.println("6. Ejercicio 6");
        System.out.println("7. Ejercicio 7");
        System.out.println("8. Ejercicio 8");
        System.out.println("9. Ejercicio 9");
        System.out.println("10. Ejercicio 10");
        System.out.println("11. Ejercicio 11");
        System.out.println("12. Ejercicio 12");
        System.out.println("13. Ejercicio 13");
        System.out.println("14. Ejercicio 14");
        System.out.println("15. Ejercicio 15");
        System.out.println("16. Ejercicio 16");
        System.out.println("17. Ejercicio 17");
        System.out.println("18. Ejercicio 18");
        System.out.println("19. Ejercicio 19");
        System.out.print("\nIntroduce opcion: ");
        byte opcion = sc.nextByte();
        switch(opcion) {
            case 1:
                ejer1();
                break;
            case 2:
                ejer2();
                break;
            case 3:
                ejer3();
                break;
            case 4:
                ejer4();
                break;
            case 5:
                ejer5();
                break;
            case 6:
                ejer6();
                break;
            case 7:
                ejer7();
                break;
            case 8:
                ejer8();
                break;
            case 9:
                ejer9();
                break;
            case 10:
                ejer10();
                break;
            case 11:
                ejer11();
                break;
            case 12:
                ejer12();
                break;
            case 13:
                ejer13();
                break;
            case 14:
                ejer14();
                break;
            case 15:
                ejer15();
                break;
            case 16:
                ejer16();
                break;
            case 17:
                ejer17();
                break;
            case 18:
                ejer18();
                break;
            case 19:
                ejer19();
                break;
        }
        System.out.println("\nFin");
    }

    public static void ejer1() {
        // 1. Rellenar y mostrar un array de tamaño 10 con números del 0 al 9

        int arr_1[]; // Declaración del array
        arr_1 = new int[10]; // Guardar 10 posiciones de memoría (0-9)
        for (int i = 0; i < arr_1.length; i++) { // Para cada posicion (empenzando por la posicion 0), comprobamos si la posicion es menor a la longitud, si se cumple se le suma 1
            arr_1[i] = i; // Asignamos el valor del índice a la posición actual
            System.out.println(i + ":" + arr_1[i]); // Mostramos la posicion del indice + : + el valor de dicha posicion
        }
    }

    public static void ejer2() {
        // 2. Rellenar y mostrar un array de tamaño 10 con numeros del 10 al 20 (11 al 20 o 10 al 19)

        int arr_2[]; // Declaración del array
        arr_2 = new int[10]; // Guardar 10 posiciones de memoría (0-9)
        for (int i = 0; i < arr_2.length; i++) { // Para cada posicion (empenzando por la posicion 0), comprobamos si la posicion es menor a la longitud, si se cumple se le suma 1
            arr_2[i] = i; // Asignamos el valor del índice a la posición actual
            arr_2[i] = i + 10; // Asignamos el valor del índice a la posición actual y le sumamos 10 para que el primer valor sea 10
            System.out.println(i + ":" + arr_2[i]); // Mostramos la posicion del indice + : + el valor de dicha posicion
        }
    }

    public static void ejer3() {
        // 3. Rellenar y mostrar un array de tamaño 10 con numeros del 10 al 1

        int arr_3[]; // Declaración del array
        arr_3 = new int[10]; // Guardar 10 posiciones de memoría (0-9)
        for (int i = arr_3.length - 1; i >= 0; i--) { // Para cada posicion de la longitud del array (-1 para empezar por el final), si i es mayor o igual a 0, le resto 1
            arr_3[i] = i + 1; // Le sumamos uno al valor para poder obtener numeros del 10 al 1
            System.out.println(i + ":" + arr_3[i]); // Mostramos el array por pantalla
        }
    }

    public static void ejer4() {
        // 4. Rellenar y mostrar un array de tamaño 10 con numeros pares del 2 al 20

        int arr_4[]; // Declaración del array
        arr_4 = new int[10]; // Guardar 10 posiciones de memoría (0-9)
        for (int i = 0; i < arr_4.length; i++) { // Para cada posicion (empenzando por la posicion 0), comprobamos si la posicion es menor a la longitud, si se cumple se le suma 1
            arr_4[i] = (i + 1) * 2; // Le sumamos uno al valor para poder obtener numeros del 10 al 1
            System.out.println(i + ":" + arr_4[i]); // Mostramos el array por pantalla
        }
    }

    public static void ejer5() {
        // 5. Rellenar un array con números introducidos por el usuario y mostrarlo

        Scanner sc = new Scanner(System.in);
        int arr_5[]; // Declaración
        arr_5 = new int[5]; // Reserva en memoría
        for (int i = 0; i < arr_5.length; i++) { // Para cada posicion (empenzando por la posicion 0), comprobamos si la posicion es menor a la longitud, si se cumple se le suma 1
            System.out.print("Introduce numero " + i + ": "); // Pedir al usuario introducir numeros segun la longitud del array
            arr_5[i] = sc.nextInt(); // Tomar los valores introducidos como valores de numeros enteros
        }
        for (int a = 0; a < arr_5.length; a++) { // Para cada posicion (empenzando por la posicion 0), comprobamos si la posicion es menor a la longitud, si se cumple se le suma 1
            System.out.println(a + ":" + arr_5[a]); // Mostramos el array por pantalla
        }
    }

    public static void ejer6() {
        // 6. Rellenar y mostrar un array de tamaño 10 con la tabla de multiplicar de un número aleatorio

        int arr_6[]; // Declaración
        arr_6 = new int[10]; // Reserva en memoría
        int numero = (int) (Math.random() * 10) + 1; // Generación de númeor rnadom entre 1 y 9 + 1
        System.out.println("Tabla de multiplicar del numero: " + numero); // Mostar por pantalla el numero de la tabla de multiplicar
        System.out.println("-----------------------------------"); // Mostar por pantalla separador
        for (int i = 0; i < arr_6.length; i++) { // Para cada posición (empezando por la posicion 0), comprobamos si la posicion es menor a la longitud total del array, si se cumple se le suma 1
            int multiplicador = i + 1; // Iniciamos la variable multiplicador con la posicion + 1 (para que llegue a 10)
            arr_6[i] = multiplicador * numero; // Multiplicamos el array por el número seleccionado aleatoriamente
            System.out.println(i + 1 + ":" + arr_6[i]); // Mostrar por pantalla el resultado del array ya multiplicado
        }
    }

    public static void ejer7() {
        // 7. Rellenar dos arrays de tamaño 10 con números aleatorios, muéstralos. A continuación, sumalos guardando el resultado en el primer array. La suma se realiza elemento a elemento como si fueran vectores.

        int arr_7[]; // Declaración
        int arr_7_2[]; // Declaración
        arr_7 = new int[10]; // Reserva en memoría
        arr_7_2 = new int[10]; // Reserva en memoría
        System.out.println("========== ARRAY 1 ================"); // Mostrar por pantalla el array 1
        for (int i = 0; i < arr_7.length; i++) { // Para cada posicion (empezando por la posicion 0), comprobamos is la posicion es menor a la longitud total de array, si se cumple se le suma 1
            arr_7[i] = (int) (Math.random() * 10); // Rellenamos el array con números aleatorios ente 1 y 10
            System.out.println(i + ":" + arr_7[i]); // Mostramos el primer array
        }
        System.out.println("========== ARRAY 2 ================");
        for (int i = 0; i < arr_7_2.length; i++) { // Para cada posicion (empezando por la posicion 0), comprobamos is la posicion es menor a la longitud total de array, si se cumple se le suma 1
            arr_7_2[i] = (int) (Math.random() * 10); // Rellenamos el array con números aleatorios ente 1 y 10
            System.out.println(i + ":" + arr_7_2[i]); // Mostramos el segundo array
        }
        System.out.println("========== SUMA DE ARRAYS ================");
        for (int i = 0; i < 10; i++) { // Para cada posicion (empezando por la posicion 0), comprobamos is la posicion es menor a 10, si se cumple se le suma 1
            arr_7[i] = arr_7[i] + arr_7_2[i]; // Declarar el primer array como la suma de los dos arrays
            System.out.println(i + ":" + arr_7[i]); // Mostrar la suma de los arrays
        }
    }

    public static void ejer8() {
        // 8. Rellenar un array de tamaño 10 con números aleatorios, muéstralo. A continuación, pide al usuario que introduzca un número. En caso de estar dicho número, el programa deberá indicar la posición o posiciones donde se encuentre dentro del array.
        Scanner sc = new Scanner(System.in); // Declaración del scanner
        int arr_8[]; // Declaración
        arr_8 = new int[10]; // Reserva en memoría
        for (int i = 0; i < arr_8.length; i++) { // Para cada posicion (empezando por la posicion 0), comprobamos is la posicion es menor a la longitud total de array, si se cumple se le suma 1
            arr_8[i] = (int) (Math.random() * 10); // Rellenamos el array con números aleatorios ente 1 y 10
            System.out.println(i + ":" + arr_8[i]); // Mostar el array por pantalla
        }
        System.out.print("Introduce un numero: "); // Pedir al usuario que introduzca un número
        int numero = sc.nextInt(); // Tomar los valores introducidos como valores de numeros enteros

        System.out.println("Resultado de la busqueda: "); // Mostrar "Resultado de la busqueda: " por pantalla
        for (int i = 0; i < arr_8.length; i++) { // Para cada posicion (empezando por la posicion 0), comprobamos is la posicion es menor a la longitud total de array, si se cumple se le suma 1 
            if (arr_8[i] == numero) // Si cada posicion del array es igual al numero
            {
                System.out.println("\nEncontrado en la posicion (indice): " + i); // Mostar por pantalla el indice del array donde se haya encontrado
            }
        }
    }

    public static void ejer9() {
        // 9. Rellenar un array de tamaño 10 con números aleatorios, muéstralo. A continuación, pide al usuario que introduzca dos números correspondientes a dos posiciones. En caso de ser posiciones válidas, el programa deberá intercambiar los valores de dichas posiciones
        Scanner sc = new Scanner(System.in);
        int arr_9[];
        arr_9 = new int[10];
        for (int i = 0; i < arr_9.length; i++) {
            arr_9[i] = (int) (Math.random() * 10);
            System.out.println(i + ":" + arr_9[i]);
        }
        System.out.print("Introduce un numero: ");
        int numero = sc.nextInt();
        System.out.print("Introduce otro numero: ");
        int numero2 = sc.nextInt();
        for (int i = 0; i < arr_9.length; i++) {
            if (numero < arr_9[i] || numero > arr_9[i]) {
                arr_9[numero] = i;
                arr_9[numero2] = i;

            }
            System.out.println(i + ":" + arr_9[i]);
        }
    }

    public static void ejer10() {
        // 10. Rellenar un array de tamaño 10 con números aleatorios, muéstralo. A continuación, muestra el mayor y el menor de los números y las posiciones donde se encuentran.
        int arr_10[];
        arr_10 = new int[10];
        for (int i = 0; i < arr_10.length; i++) {
            arr_10[i] = (int) (Math.random() * 10);
            System.out.println(i + ":" + arr_10[i]);
        }
        // Inicializar mayor y menor
        int mayor = arr_10[0];
        int menor = arr_10[0];
        int posMayor = 0;
        int posMenor = 0;

        // Buscar mayor y menor
        for (int i = 1; i < arr_10.length; i++) {
            if (arr_10[i] > mayor) {
                mayor = arr_10[i];
                posMayor = i;
            }
            if (arr_10[i] < menor) {
                menor = arr_10[i];
                posMenor = i;
            }
        }
        // Mostrar resultados
        System.out.println("\nMayor: " + mayor + " en posicion " + posMayor);
        System.out.println("Menor: " + menor + " en posicion " + posMenor);
    }

    public static void ejer11() {
        // 11. Rellenar un array de tamaño 10 con números aleatorios, muéstralo. A continuación, muestra la suma y la media de todos los valores.
        int arr_11[];
        arr_11 = new int[10];
        for (int i = 0; i < arr_11.length; i++) {
            arr_11[i] = (int) (Math.random() * 10);
            System.out.println(i + ":" + arr_11[i]);
        }
        // Calcular suma y media
        int suma = 0;
        for (int i = 0; i < arr_11.length; i++) {
            suma += arr_11[i];
        }
        double media = (double) suma / arr_11.length;

        // Mostrar resultados
        System.out.println("Suma: " + suma);
        System.out.println("Media: " + media);
    }

    public static void ejer12() {
        // 12. Crea un array de números aleatorios de un tamaño pasado por teclado. El array contendrá números aleatorios entre 1 y 300 y se deberá mostrar aquellos números que acaben en un dígito que el usuario indique por teclado. Se debe controlar que se introduce un numero correcto, estos deben guardarse en un nuevo array.
        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce la longitud del array: ");
        int numero = sc.nextInt();

        int arr_12[];
        arr_12 = new int[numero];

        for (int i = 0; i < arr_12.length; i++) {
            arr_12[i] = (int) (Math.random() * 300) + 1;
            System.out.println(i + ":" + arr_12[i]);
        }

        System.out.print("Introduce el dígito final (0-9): ");
        int numero2 = sc.nextInt();

        while (numero2 < 0 || numero2 > 9) {
            System.out.print("Error. Introduce un dígito del 0 al 9: ");
            numero2 = sc.nextInt();
        }

        int contador = 0;

        // Contar los números que terminan en el dígito indicado
        for (int i = 0; i < arr_12.length; i++) {
            if (arr_12[i] % 10 == numero2) {
                contador++;
            }
        }

        int arr_12_final[];
        arr_12_final = new int[contador];

        // COPIAR los números al nuevo array
        int posicion = 0;

        for (int i = 0; i < arr_12.length; i++) {
            if (arr_12[i] % 10 == numero2) {
                arr_12_final[posicion] = arr_12[i];
                posicion++;
            }
        }

        // Mostrar el nuevo array

        for (int i = 0; i < arr_12_final.length; i++) {
            System.out.print(arr_12_final[i]);

            if (i < arr_12_final.length - 1) {
                System.out.print(", ");
            }
        }
    }
    public static void ejer13() {
        // 13. Rellenar un array de tamaño 10 con números aleatorios, muéstralo. A continuación, desplaza todos los elementos una posición a la derecha y muestra el array
        int arr_13[]; // Declaración
        arr_13 = new int[10];
        for (int i = 0; i < arr_13.length; i++) {
            arr_13[i] = (int) (Math.random() * 10);
            System.out.println(i + ":" + arr_13[i]);
        }
        // Desplazar todos los elementos una posición a la derecha
        int ultimo = arr_13[arr_13.length - 1];
        for (int i = arr_13.length - 1; i > 0; i--) {
            arr_13[i] = arr_13[i - 1];
        }
        arr_13[0] = ultimo;

        // Mostrar array desplazado
        System.out.println("\nArray desplazado a la derecha:");
        for (int i = 0; i < arr_13.length; i++) {
            System.out.println(i + ":" + arr_13[i]);
        }
    }
    public static void ejer14() {
        // 14. Rellenar un array de tamaño 10 con números aleatorios, muéstralo. A continuación, desplaza todos los elementos una posición a la izquierda y muestra el array
        int arr_14[]; // Declaración
        arr_14 = new int[10];
        for (int i = 0; i < arr_14.length; i++) {
            arr_14[i] = (int) (Math.random() * 10);
            System.out.println(i + ":" + arr_14[i]);
        }
        // Desplazar todos los elementos una posición a la izquierda
        int primero = arr_14[0];
        for (int i = 0; i < arr_14.length - 1; i++) {
            arr_14[i] = arr_14[i + 1];
        }
        arr_14[arr_14.length - 1] = primero;

        // Mostrar array desplazado
        System.out.println("\nArray desplazado a la izquierda:");
        for (int i = 0; i < arr_14.length; i++) {
            System.out.println(i + ":" + arr_14[i]);
        }
    }
    public static void ejer15() {
        // 15. Rellenar un array de tamaño 10 con números aleatorios, muéstralo. A continuación, invierte todos los elementos y muestra el array. El elemento de la posición 0 se intercambia por el de la 9, la 1 por la 8 ...

        int arr_15[] = new int[10];

        // Rellenar con números aleatorios entre 0 y 9
        for (int i = 0; i < arr_15.length; i++) {
            arr_15[i] = (int) (Math.random() * 10);
        }

        // Mostrar array original
        System.out.println("Array original:");
        for (int i = 0; i < arr_15.length; i++) {
            System.out.println(i + ":" + arr_15[i]);
        }

        // Invertir el array
        for (int i = 0; i < arr_15.length / 2; i++) {
            int temp = arr_15[i];
            arr_15[i] = arr_15[arr_15.length - 1 - i];
            arr_15[arr_15.length - 1 - i] = temp;
        }

        // Mostrar array invertido
        System.out.println("\nArray invertido:");
        for (int i = 0; i < arr_15.length; i++) {
            System.out.println(i + ":" + arr_15[i]);
        }
    }
    public static void ejer16() {
        // 16. Crea un array de números y otro de String de 10 posiciones donde insertaremos notas entre 0 y 10 (debemos controlar que inserte una nota valida), pudiendo ser decimal la nota en el array de números, en el de Strings se insertaran los nombres de los alumnos.
        // Después, crearemos un array de String donde insertaremos el resultado de la nota con palabras.
        // Si la nota esta entre 0 y 4,99 , sera un suspenso
        // Si esta entre 5 y 6,99 , sera un bien.
        // Si esta entre 7 y 8,99 sera un notable.
        // Si esta entre 9 y 10 sera un sobresaliente.
        // Muestra por pantalla, el alumno su nota y su resultado en palabras.
    }
    
    public static void ejer17() {
        // 17. Crea dos arrays de tamaño 5 y rellenalos manualmente. El programa deberá indicar si los dos arrays son iguales
        // Crear los dos arrays de tamaño 5
        int arr_17 [] = new int[5];
        int arr_17_2 [] = new int[5];

        // Rellenar el primer array
        arr_17[0] = 1;
        arr_17[1] = 2;
        arr_17[2] = 3;
        arr_17[3] = 4;
        arr_17[4] = 5;

        // Rellenar el segundo array
        arr_17_2[0] = 1;
        arr_17_2[1] = 2;
        arr_17_2[2] = 3;
        arr_17_2[3] = 4;
        arr_17_2[4] = 5;

        boolean iguales = true;

        // Comparar los dos arrays
        for (int i = 0; i < 5; i++) {
            if (arr_17[i] != arr_17_2[i]) {
                iguales = false;
            }
        }

        // Mostrar el resultado
        if (iguales) {
            System.out.println("\nLos arrays son iguales");
        } else {
            System.out.println("Los arrays son diferentes");
        }
    }
    public static void ejer18() {
        // 18. Pide al usuario que introduzca un número. Los dígitos de dicho número deberán pasarse a un array. A continuación, deberá indicarse si el número es capicua (se lee igual en los dos sentidos)
        Scanner sc = new Scanner(System.in);

        // Pedir un número al usuario
        System.out.print("Introduce un numero: ");
        int numero = sc.nextInt();

        int auxiliar = numero;
        int contador = 0;

        // Contar los dígitos del número
        while (auxiliar > 0) {
            contador++;
            auxiliar = auxiliar / 10;
        }

        // Crear el array
        int arr_18 [] = new int[contador];

        // Guardar los dígitos en el array
        auxiliar = numero;

        for (int i = contador - 1; i >= 0; i--) {
            arr_18[i] = auxiliar % 10;
            auxiliar = auxiliar / 10;
        }

        // Comprobar si es capicúa
        boolean capicua = true;

        for (int i = 0; i < contador / 2; i++) {
            if (arr_18[i] != arr_18[contador - 1 - i]) {
                capicua = false;
            }
        }

        // Mostrar el resultado
        if (capicua) {
            System.out.println("El número es capicua.");
        } else {
            System.out.println("El número no es capicua.");
        }
    }
    public static void ejer19() {
        // 19. Genera un número aleatorio entre 5 y 10, ambos incluidos. A continuación, crea un array cuya longitud sea la del número generado y rellenado con números aleatorios. El array no debe mostrarse. Después, el programa pedirá números al usuario que deberá adivinar los números contenidos en el array. Para ello, el programa sólo permitirá 3 fallos, es decir, 3 números NO CONTENIDOS en el array que el usuario haya seleccionado. El programa terminará cuando el usuario haya adivinado todos los números, o cuando haya fallado 3 veces o si el usuario introduce un número negativo.
        
        Scanner sc = new Scanner(System.in);

        // Generar longitud aleatoria entre 5 y 10
        int longitud = (int) (Math.random() * 6) + 5;

        // Crear y rellenar el array
        int arr_19[] = new int[longitud];

        for (int i = 0; i < longitud; i++) {
            arr_19[i] = (int) (Math.random() * 10) + 1;
        }

        int fallos = 0;
        int acertados = 0;
        boolean continuar = true;

        // Comenzar el juego
        while (fallos < 3 && acertados < longitud && continuar) {

            System.out.print("Introduce un numero: ");
            int numero = sc.nextInt();

            if (numero < 0) {
                continuar = false;
            } else {

                boolean encontrado = false;

                // Buscar el número en el array
                for (int i = 0; i < longitud; i++) {

                    if (arr_19[i] == numero && !encontrado) {
                        encontrado = true;
                        arr_19[i] = -1;
                        acertados++;
                    }
                }

                if (encontrado) {
                    System.out.println("Numero acertado.");
                } else {
                    fallos++;
                    System.out.println("Numero incorrecto. Fallos: " + fallos);
                }
            }
        }

        // Mostrar resultado
        if (acertados == longitud) {
            System.out.println("¡Has adivinado todos los números!");
        } else {
            System.out.println("Fin del juego.");
        }

    }
}
